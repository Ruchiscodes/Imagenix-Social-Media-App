import Home from "./home";
import Login from "./login";
import Pins from "./pins";
import UserProfile from "./userProfile";
import CreatePin from "./createPin";
import PinDetail from "./PinDetail";

export { Home, Login, UserProfile, Pins, CreatePin, PinDetail };
